CREATE PROCEDURE proc_test()
  BEGIN 
    DECLARE v INT; 
    SET v = 0; 
    WHILE v < 150 DO 
         update phteleclos_wake set sta='T',changed=now() where sta='F' and (wktime<DATE_SUB(now(),INTERVAL '1' HOUR) or (accnt is null or accnt =''));
        SET v = v + 1; 
    END WHILE; 
END;

