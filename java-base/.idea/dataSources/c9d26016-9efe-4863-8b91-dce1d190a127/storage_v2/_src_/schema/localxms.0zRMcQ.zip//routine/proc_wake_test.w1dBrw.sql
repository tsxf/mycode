CREATE PROCEDURE proc_wake_test()
  begin
  call proc_test();
end;

